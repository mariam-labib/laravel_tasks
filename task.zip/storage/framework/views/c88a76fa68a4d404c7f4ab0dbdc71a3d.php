<!DOCTYPE html>
<html>
<head>
    <title>Add Category</title>
</head>
<body>
    <h1>Add New Category</h1>

    <form action="<?php echo e(route('categories.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <p>
            <label>Category Name:</label><br>
            <input type="text" name="name" required>
        </p>
        <button type="submit">Save Category</button>
    </form>
    
    <br>
    <a href="<?php echo e(route('categories.index')); ?>">← Back to Categories</a>
</body>
</html><?php /**PATH C:\Users\precision 5550\Desktop\project_iti\resources\views/categories/create.blade.php ENDPATH**/ ?>