<!DOCTYPE html>
<html>
<head>
    <title>Add Product</title>
</head>
<body>
    <h1>Add New Product</h1>

    <form action="<?php echo e(route('products.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <p>
            <label>Product Name:</label><br>
            <input type="text" name="name" required>
        </p>
        <p>
            <label>Price:</label><br>
            <input type="number" step="0.01" name="price" required>
        </p>
        <p>
            <label>Category:</label><br>
            <select name="category_id" required>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </p>
        <button type="submit">Save Product</button>
    </form>
    
    <br>
    <a href="<?php echo e(route('products.index')); ?>">← Back to Products</a>
</body>
</html><?php /**PATH C:\Users\precision 5550\Desktop\project_iti\resources\views/products/create.blade.php ENDPATH**/ ?>