<!DOCTYPE html>
<html>
<head>
    <title>Categories List</title>
</head>
<body>
    <a href="<?php echo e(route('categories.create')); ?>">+ Add New Category</a>
    <hr>
    <h1>Categories List</h1>

    <ul>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li style="margin-bottom: 10px;">
                <strong><?php echo e($category->name); ?></strong>
                | <a href="<?php echo e(route('categories.edit', $category->id)); ?>">Edit</a>
                | <form action="<?php echo e(route('categories.destroy', $category->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" onclick="return confirm('Delete this category?')">Delete</button>
                </form>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <br>
    <a href="<?php echo e(route('products.index')); ?>">← Go to Products List</a>
</body>
</html><?php /**PATH C:\Users\precision 5550\Desktop\project_iti\resources\views/categories/index.blade.php ENDPATH**/ ?>