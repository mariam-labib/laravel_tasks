<!DOCTYPE html>
<html>
<head>
    <title>Edit Category</title>
</head>
<body>
    <h1>Edit Category</h1>

    <form action="<?php echo e(route('categories.update', $category->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <p>
            <label>Category Name:</label><br>
            <input type="text" name="name" value="<?php echo e($category->name); ?>" required>
        </p>
        <button type="submit">Update Category</button>
    </form>
    
    <br>
    <a href="<?php echo e(route('categories.index')); ?>">← Back to Categories</a>
</body>
</html><?php /**PATH C:\Users\precision 5550\Desktop\project_iti\resources\views/categories/edit.blade.php ENDPATH**/ ?>