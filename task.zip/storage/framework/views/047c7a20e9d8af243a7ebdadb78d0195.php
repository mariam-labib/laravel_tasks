<!DOCTYPE html>
<html>
<head>
    <title>Products List</title>
</head>
<body>

    <a href="<?php echo e(route('products.create')); ?>">+ Add New Product</a>
    <hr>

    <h1>Products List</h1>

    <ul>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li style="margin-bottom: 10px;">
                <strong><?php echo e($product->name); ?></strong> - 
                Price: <?php echo e(number_format($product->price, 2)); ?> $ 
                (Category: <?php echo e($product->category->name ?? 'No Category'); ?>)
                
            
                | <a href="<?php echo e(route('products.edit', $product->id)); ?>">Edit</a>

            
                | <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" onclick="return confirm('Are you sure you want to delete this product?')">Delete</button>
                </form>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <br>
    <a href="<?php echo e(route('categories.index')); ?>">← Go to Categories List</a>

</body>
</html><?php /**PATH C:\Users\precision 5550\Desktop\project_iti\resources\views/products/index.blade.php ENDPATH**/ ?>